package com.apress.prospring2.ch14.dsl;

/**
 * @author janm
 */
public interface CustomerScoringService {

    double score(Customer customer);

}
