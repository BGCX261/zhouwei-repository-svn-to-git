package com.apress.prospring2.ch05.aspectj;

/**
 * Created by aleksav
 */
public class SampleBean {

    public String getName() {
        return "Aleksa V";
    }

    public void setName(String name) {

    }

    public int getHeight() {
        return 201;
    }
}
