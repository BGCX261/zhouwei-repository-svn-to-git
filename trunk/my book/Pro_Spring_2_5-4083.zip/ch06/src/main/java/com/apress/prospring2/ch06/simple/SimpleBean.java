package com.apress.prospring2.ch06.simple;

/**
 * @author janm
 */
public class SimpleBean {

    public void sayHello() {
        System.out.println("Hello");
    }

    public void x(CharSequence a, String b) {
        
    }

}
