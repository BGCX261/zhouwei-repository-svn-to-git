package com.apress.prospring2.ch05.cflow;

/**
 * @author janm
 */
public class TestBean {

    public void foo() {
        System.out.println("foo");
    }

}
