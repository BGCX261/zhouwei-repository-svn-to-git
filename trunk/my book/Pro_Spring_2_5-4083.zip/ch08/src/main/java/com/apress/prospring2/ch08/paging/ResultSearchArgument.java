package com.apress.prospring2.ch08.paging;

/**
 * @author janm
 */
public class ResultSearchArgument extends SearchArgumentSupport {
    private String s;

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }
}
