package com.apress.prospring2.ch08.structural.wrapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * @author janm
 */
public class RequestDemo {

    public static void main(String[] args) {
        
    }

}
