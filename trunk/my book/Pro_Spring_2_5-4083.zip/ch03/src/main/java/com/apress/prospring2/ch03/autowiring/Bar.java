package com.apress.prospring2.ch03.autowiring;

/**
 * @author janm
 */
public class Bar {

    @Override
    public String toString() {
        return getClass().getName();
    }
}
