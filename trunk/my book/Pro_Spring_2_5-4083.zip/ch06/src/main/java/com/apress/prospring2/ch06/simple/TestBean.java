package com.apress.prospring2.ch06.simple;

/**
 * @author janm
 */
public class TestBean {

    public void work() {
        System.out.println("work");
    }

    public void stop() {
        System.out.println("stop");
    }

}
