package com.apress.prospring2.ch08.structural.decorator;

/**
 * @author janm
 */
public class Decorated {
}
