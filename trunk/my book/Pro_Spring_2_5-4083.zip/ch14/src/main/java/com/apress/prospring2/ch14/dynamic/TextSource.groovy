class GroovyTextSource implements com.apress.prospring2.ch14.beans.TextSource {
    public String getMessage() { return "Hello, world"}
}
