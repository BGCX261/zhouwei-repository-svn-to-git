package com.apress.prospring2.ch08.unitofwork;

/**
 * @author janm
 */
public class Category {
}
