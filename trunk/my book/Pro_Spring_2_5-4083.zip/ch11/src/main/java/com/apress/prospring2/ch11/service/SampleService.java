package com.apress.prospring2.ch11.service;

/**
 * @author janm
 */
public interface SampleService {

    void work();

}
