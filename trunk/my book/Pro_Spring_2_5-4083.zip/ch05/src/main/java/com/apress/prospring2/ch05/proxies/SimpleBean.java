package com.apress.prospring2.ch05.proxies;

/**
 * @author janm
 */
public class SimpleBean implements ISimpleBean {

    public void advised() {

    }

    public void unadvised() {

    }
}
