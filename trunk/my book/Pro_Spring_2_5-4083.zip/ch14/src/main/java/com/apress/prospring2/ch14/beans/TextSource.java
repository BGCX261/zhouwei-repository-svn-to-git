package com.apress.prospring2.ch14.beans;

/**
 * @author janm
 */
public interface TextSource {

    String getMessage();

}
