package com.apress.prospring2.ch08.paging;

/**
 * @author janm
 */
public class ResultSearchResult extends SearchResultSupport<Result> {
}
