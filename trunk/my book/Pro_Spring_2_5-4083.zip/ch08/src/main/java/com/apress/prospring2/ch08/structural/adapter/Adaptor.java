package com.apress.prospring2.ch08.structural.adapter;

/**
 * @author janm
 */
public class Adaptor {

    

}
