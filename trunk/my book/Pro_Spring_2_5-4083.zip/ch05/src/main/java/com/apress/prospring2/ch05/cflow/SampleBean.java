package com.apress.prospring2.ch05.cflow;

/**
 * @author janm
 */
public class SampleBean {

    public String getName() {
        return "Springfield Springy";
    }

    public void setName(String name) {

    }

    public int getAge() {
        return 100;
    }
}
