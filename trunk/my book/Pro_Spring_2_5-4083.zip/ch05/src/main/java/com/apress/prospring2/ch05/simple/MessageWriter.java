package com.apress.prospring2.ch05.simple;

/**
 * @author janm
 */
public class MessageWriter {
    
    public void writeMessage() {
        System.out.print("World");
    }
}
