package com.apress.prospring2.ch03.di;

/**
 * @author janm
 */
public interface Oracle {

    String defineMeaningOfLife();

}
