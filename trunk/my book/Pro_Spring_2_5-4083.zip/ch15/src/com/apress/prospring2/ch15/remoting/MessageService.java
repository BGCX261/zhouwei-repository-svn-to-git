package com.apress.prospring2.ch15.remoting;


/**
 * @author aleksav
 */
public interface MessageService {

    MessageBean getMessage();
}
