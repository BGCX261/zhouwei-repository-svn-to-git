package com.apress.prospring2.ch08.scheduling;

/**
 * @author janm
 */
public class ScheduledBean {

    public void render() {
        System.out.println("Run.");
    }

}
