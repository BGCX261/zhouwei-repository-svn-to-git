package com.apress.prospring2.ch15.remoting;

/**
 * @author aleksav
 */
public class SimpleHelloWorld implements HelloWorld {

    public String getMessage() {
        return "Hello World";
    }

}
