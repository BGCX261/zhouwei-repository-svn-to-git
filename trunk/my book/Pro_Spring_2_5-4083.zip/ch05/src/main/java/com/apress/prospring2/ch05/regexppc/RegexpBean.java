package com.apress.prospring2.ch05.regexppc;

/**
 * @author janm
 */
public class RegexpBean {

    public void foo1() {
        System.out.println("foo1");
    }

    public void foo2() {
        System.out.println("foo2");
    }

    public void bar() {
        System.out.println("bar");
    }
}
