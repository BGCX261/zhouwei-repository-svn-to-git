package com.apress.prospring2.ch14;

/**
 * @author janm
 */
public interface Checker {

    boolean check(String value);

}
