package com.apress.prospring2.ch05.security;

/**
 * @author janm
 */
public class SecureBean {

    public void writeSecureMessage() {
        System.out.println("Every time I learn something new, "
                + "it pushes some old stuff out of my brain");
    }
}
