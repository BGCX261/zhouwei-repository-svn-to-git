package com.apress.prospring2.ch05.proxies;

/**
 * @author janm
 */
public interface ISimpleBean {

    void advised();

    void unadvised();

}
