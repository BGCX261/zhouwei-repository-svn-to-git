package com.apress.prospring2.ch16.synchronization;

/**
 * @author janm
 */
public interface WorkerFactory {

    Worker create();

}
