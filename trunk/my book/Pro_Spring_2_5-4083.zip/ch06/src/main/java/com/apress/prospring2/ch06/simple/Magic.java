package com.apress.prospring2.ch06.simple;

/**
 * @author janm
 */
public @interface Magic {
}
