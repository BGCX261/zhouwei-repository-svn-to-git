package com.apress.prospring2.ch05.staticpc;

/**
 * @author janm
 */
public class BeanOne {

    public void foo() {
        System.out.println("foo");
    }

    public void bar() {
        System.out.println("bar");
    }

}
