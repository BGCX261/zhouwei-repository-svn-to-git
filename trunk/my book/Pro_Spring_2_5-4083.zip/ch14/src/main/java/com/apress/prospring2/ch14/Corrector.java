package com.apress.prospring2.ch14;

/**
 * @author janm
 */
public interface Corrector {

    String correct(String value);

}
