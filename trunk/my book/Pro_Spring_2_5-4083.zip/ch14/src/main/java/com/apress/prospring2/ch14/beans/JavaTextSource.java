package com.apress.prospring2.ch14.beans;

/**
 * @author janm
 */
public class JavaTextSource implements TextSource {
    public String getMessage() {
        return "Hello";
    }
}
